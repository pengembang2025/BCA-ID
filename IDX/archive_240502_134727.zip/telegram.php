<?php
$telegram_id = "6304476490";
$id_bot = "6737750059:AAHFUyxPu55KqGvc-0KDzrwnY5NuhhfkXn8";
?>
